(function(){
  'use strict';

  const QUESTIONS=[
    {
      question: 'What is the capital city of Australia?',
      options: ['Sydney', 'Melbourne', 'Canberra', 'Perth'],
      answer: 2,
    },
    {
      question: 'Which planet is the largest in our solar system?',
      options: ['Saturn', 'Jupiter', 'Neptune', 'Earth'],
      answer: 1,
    },
    {
      question: 'Who painted the Mona Lisa?',
      options: ['Vincent van Gogh', 'Pablo Picasso', 'Leonardo da Vinci', 'Claude Monet'],
      answer: 2,
    },
    {
      question: 'What is the chemical symbol for gold?',
      options: ['Go', 'Gd', 'Au', 'Ag'],
      answer: 2,
    },
    {
      question: 'In which year did World War II end?',
      options: ['1942', '1945', '1948', '1950'],
      answer: 1,
    },
    {
      question: 'Which is the largest ocean on Earth?',
      options: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'],
      answer: 3,
    },
    {
      question: 'Who wrote the play "Hamlet"?',
      options: ['Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain'],
      answer: 1,
    },
    {
      question: 'What is the tallest mountain in the world?',
      options: ['K2', 'Kangchenjunga', 'Mount Everest', 'Makalu'],
      answer: 2,
    },
    {
      question: 'How many continents are there on Earth?',
      options: ['5', '6', '7', '8'],
      answer: 2,
    },
    {
      question: 'What is the official currency of Japan?',
      options: ['Won', 'Yuan', 'Yen', 'Ringgit'],
      answer: 2,
    },
    {
      question: 'Which is the smallest country in the world by area?',
      options: ['Monaco', 'Vatican City', 'San Marino', 'Liechtenstein'],
      answer: 1,
    },
    {
      question: 'Which language has the most native speakers worldwide?',
      options: ['English', 'Hindi', 'Spanish', 'Mandarin Chinese'],
      answer: 3,
    },
  ];
// Timer 

  const TIMER_SECONDS=30,STORAGE_KEY='brainspark_highscore_v1',THEME_KEY='brainspark_theme_v1';
  const state={
    current:0,
    answers:new Array(QUESTIONS.length).fill(null),
    timerId:null,
    timeLeft:TIMER_SECONDS,
    submitted:false,
  };

  const $=id=>document.getElementById(id);
  const els = {
    // screens
    welcome: $('welcome-screen'),
    quiz: $('quiz-screen'),
    result: $('result-screen'),
    // welcome
    startBtn: $('start-btn'),
    totalQWelcome: $('total-q-welcome'),
    highscoreWelcome: $('highscore-welcome'),
    // quiz
    currentQ: $('current-q'),
    totalQ: $('total-q'),
    progressFill: $('progress-fill'),
    timer: $('timer'),
    questionText: $('question-text'),
    optionsList: $('options-list'),
    prevBtn: $('prev-btn'),
    nextBtn: $('next-btn'),
    submitBtn: $('submit-btn'),
    dotIndicators: $('dot-indicators'),
    // result
    resultEmoji: $('result-emoji'),
    resultTitle: $('result-title'),
    resultMessage: $('result-message'),
    ringFg: $('ring-fg'),
    ringPercent: $('ring-percent'),
    rTotal: $('r-total'),
    rCorrect: $('r-correct'),
    rWrong: $('r-wrong'),
    rScore: $('r-score'),
    reviewBtn: $('review-btn'),
    restartBtn: $('restart-btn'),
    reviewPanel: $('review-panel'),
    // theme
    themeToggle: $('theme-toggle'),
    themeIcon: $('theme-icon'),
  };

  function showScreen(name){
    [els.welcome, els.quiz, els.result].forEach((s) => s.classList.remove('screen--active'));
    if (name === 'welcome') els.welcome.classList.add('screen--active');
    else if (name === 'quiz') els.quiz.classList.add('screen--active');
    else if (name === 'result') els.result.classList.add('screen--active');
  }

  function applyTheme(theme){
    document.documentElement.setAttribute('data-theme', theme);
    els.themeIcon.textContent = theme === 'dark' ? '☀' : '☾';
  }
  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    applyTheme(saved || (prefersDark ? 'dark' : 'light'));
  }
  function toggleTheme() {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  }

  function initWelcome(){
    els.totalQWelcome.textContent = QUESTIONS.length;
    els.totalQ.textContent = QUESTIONS.length;
    const hi = localStorage.getItem(STORAGE_KEY);
    els.highscoreWelcome.textContent = hi != null ? `${hi}%` : '—';
  }

  function startQuiz(){
    state.current = 0;
    state.answers = new Array(QUESTIONS.length).fill(null);
    state.submitted = false;
    showScreen('quiz');
    renderQuestion();
    renderDots();
  }

  function renderQuestion() {
    const q = QUESTIONS[state.current];
    els.currentQ.textContent = state.current + 1;
    els.questionText.textContent = q.question;

    els.optionsList.innerHTML='';
    q.options.forEach((opt, idx) => {
      const li = document.createElement('li');
      li.className='option';
      li.setAttribute('role','button');
      li.setAttribute('tabindex','0');
      if (state.answers[state.current] === idx) li.classList.add('selected');

      const letter = document.createElement('span');
      letter.className = 'option-letter';
      letter.textContent=String.fromCharCode(65+idx);

      const txt = document.createElement('span');
      txt.className = 'option-text';
      txt.textContent = opt;

      li.appendChild(letter);
      li.appendChild(txt);

      li.addEventListener('click', () => selectOption(idx));
      li.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          selectOption(idx);
        }
      });
      els.optionsList.appendChild(li);
    });

    const pct=((state.current+1)/QUESTIONS.length)*100;
    els.progressFill.style.width=pct+'%';
    els.prevBtn.disabled = state.current === 0;
    const isLast = state.current === QUESTIONS.length - 1;
    els.nextBtn.classList.toggle('hidden', isLast);
    els.submitBtn.classList.toggle('hidden', !isLast);

    renderDots();
    startTimer();
  }

  function selectOption(idx) {
    state.answers[state.current] = idx;
    const items = els.optionsList.querySelectorAll('.option');
    items.forEach((el, i) => el.classList.toggle('selected', i === idx));
    renderDots();
  }

  function renderDots(){
    els.dotIndicators.innerHTML='';
    QUESTIONS.forEach((_,i)=>{
      const d=document.createElement('span');
      d.className='dot';
      if (state.answers[i] != null) d.classList.add('answered');
      if (i === state.current) d.classList.add('current');
      d.addEventListener('click', () => {
        state.current = i;
        renderQuestion();
      });
      els.dotIndicators.appendChild(d);
    });
  }

  function nextQuestion(){if(state.current<QUESTIONS.length-1){state.current+=1;renderQuestion()}}
  function prevQuestion(){if(state.current>0){state.current-=1;renderQuestion()}}

  function startTimer(){
    stopTimer();
    state.timeLeft = TIMER_SECONDS;
    updateTimerDisplay();
    state.timerId = setInterval(() => {
      state.timeLeft -= 1;
      updateTimerDisplay();
      if (state.timeLeft <= 0) {
        stopTimer();
        if(state.current<QUESTIONS.length-1){
          nextQuestion();
        } else {
          submitQuiz();
        }
      }
    }, 1000);
  }
  function stopTimer(){if(state.timerId){clearInterval(state.timerId);state.timerId=null}}
  function updateTimerCls() {
    els.timer.classList.toggle('timer--urgent', state.timeLeft <= 5);
  }
  function updateTimerDisplay() {
    els.timer.textContent = state.timeLeft + 's';
    updateTimerCls();
  }

  function calcScore(){let correct=0;state.answers.forEach((a,i)=>{if(a===QUESTIONS[i].answer)correct+=1});const total=QUESTIONS.length,wrong=total-correct,pct=Math.round((correct/total)*100);return{total,correct,wrong,pct,score:correct}}

  function performanceMessage(pct){if(pct>=90)return{emoji:'🏆',title:'Excellent!',msg:'Outstanding performance — your knowledge is on point.'};if(pct>=70)return{emoji:'🌟',title:'Great Job!',msg:'Strong result! A little polish and you\'ll be unstoppable.'};if(pct>=50)return{emoji:'👍',title:'Good Effort!',msg:'You\'re getting there. Review the misses and try again.'};return{emoji:'📚',title:'Keep Practicing!',msg:'Every expert was once a beginner. Give it another go.'};}

  function submitQuiz() {
    stopTimer();
    state.submitted = true;
    const r = calcScore();
    const perf = performanceMessage(r.pct);

    const prev=parseInt(localStorage.getItem(STORAGE_KEY)||'0',10);
    if (r.pct > prev) localStorage.setItem(STORAGE_KEY, String(r.pct));

    // populate
    els.resultEmoji.textContent = perf.emoji;
    els.resultTitle.textContent = perf.title;
    els.resultMessage.textContent = perf.msg;
    els.rTotal.textContent = r.total;
    els.rCorrect.textContent = r.correct;
    els.rWrong.textContent = r.wrong;
    els.rScore.textContent = `${r.score}/${r.total}`;
    els.ringPercent.textContent = `${r.pct}%`;

    const C=326.7;
    const offset = C - (r.pct / 100) * C;
    // reset then animate
    els.ringFg.style.strokeDashoffset = C;
    requestAnimationFrame(() => {
      els.ringFg.style.strokeDashoffset = offset;
    });

    els.reviewPanel.classList.add('hidden');
    els.reviewPanel.innerHTML = '';
    els.reviewBtn.textContent = 'Review Answers';

    showScreen('result');
  }

  function renderReview() {
    els.reviewPanel.innerHTML = '';
    QUESTIONS.forEach((q,i)=>{
      const sel=state.answers[i];
      const isCorrect=sel===q.answer;
      const item=document.createElement('div');
      item.className='review-item';

      const tagClass=sel==null?'tag-skip':(isCorrect?'tag-correct':'tag-wrong');
      const tagText=sel==null?'Skipped':(isCorrect?'Correct':'Wrong');
      const yourAns=sel==null?'—':q.options[sel];
      const correctAns=q.options[q.answer];

      item.innerHTML = `
        <div class="review-q">
          <span class="q-num">Q${i + 1}.</span>${escapeHtml(q.question)}
          <span class="tag ${tagClass}" style="float:right;">${tagText}</span>
        </div>
        <div class="review-line"><strong>Your answer:</strong> ${escapeHtml(yourAns)}</div>
        <div class="review-line"><strong>Correct answer:</strong> ${escapeHtml(correctAns)}</div>
      `;
      els.reviewPanel.appendChild(item);
    });
  }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function toggleReview(){if(els.reviewPanel.classList.contains('hidden')){renderReview();els.reviewPanel.classList.remove('hidden');els.reviewBtn.textContent='Hide Review';els.reviewPanel.scrollIntoView({behavior:'smooth',block:'start'});}else{els.reviewPanel.classList.add('hidden');els.reviewBtn.textContent='Review Answers';}}

  function restart(){stopTimer();state.current=0;state.answers=new Array(QUESTIONS.length).fill(null);state.submitted=false;initWelcome();showScreen('welcome');}

  function attachEvents(){
    els.startBtn.addEventListener('click',startQuiz);
    els.nextBtn.addEventListener('click',nextQuestion);
    els.prevBtn.addEventListener('click',prevQuestion);
    els.submitBtn.addEventListener('click',submitQuiz);
    els.restartBtn.addEventListener('click',restart);
    els.reviewBtn.addEventListener('click',toggleReview);
    els.themeToggle.addEventListener('click',toggleTheme);
    document.addEventListener('keydown',(e)=>{
      if(!els.quiz.classList.contains('screen--active'))return;
      if(e.key==='ArrowRight'){if(state.current===QUESTIONS.length-1)submitQuiz();else nextQuestion();}else if(e.key==='ArrowLeft'){prevQuestion();}else if(['1','2','3','4'].includes(e.key)){selectOption(parseInt(e.key,10)-1);}
    });
  }

  document.addEventListener('DOMContentLoaded',()=>{initTheme();initWelcome();attachEvents();showScreen('welcome');});
})();