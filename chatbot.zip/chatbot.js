/* ============================================================
   CHATBOT - GEMINI API INTEGRATION
   ============================================================ */

const CONFIG = {
  // Your Gemini API key from Google AI Studio.
  apiKey: "AQ.Ab8RN6LpYuPD9hyCCVdHBLOzLTTZuAwm7w8nzr9X-WHkpR-MEg",

  // Use a model name that exists in the Gemini API model list.
  model: "gemini-2.5-flash",

  // A system prompt to steer the assistant's behavior.
  systemPrompt: "You are a friendly, concise, and helpful assistant."
};

const chatWindow = document.getElementById("chatWindow");
const chatForm = document.getElementById("chatForm");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const typingIndicator = document.getElementById("typingIndicator");
const clearBtn = document.getElementById("clearBtn");

// Gemini keeps conversation turns as { role, parts: [{ text }] }.
// Roles are "user" and "model" (not "assistant").
let conversation = [];

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = userInput.value.trim();
  if (!text) return;

  addMessage(text, "user");
  conversation.push({ role: "user", parts: [{ text }] });
  userInput.value = "";
  setLoading(true);

  try {
    const reply = await getBotReply(conversation);
    addMessage(reply, "bot");
    conversation.push({ role: "model", parts: [{ text: reply }] });
  } catch (err) {
    console.error(err);
    addMessage(
      `Something went wrong: ${err.message}. Check your API key in script.js.`,
      "error"
    );
  } finally {
    setLoading(false);
  }
});

clearBtn.addEventListener("click", () => {
  conversation = [];
  chatWindow.innerHTML = "";
  addMessage("Conversation cleared. Ask me anything!", "bot");
});

function addMessage(text, type) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${type}`;

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  wrapper.appendChild(bubble);
  chatWindow.appendChild(wrapper);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function setLoading(isLoading) {
  sendBtn.disabled = isLoading;
  typingIndicator.classList.toggle("hidden", !isLoading);
  if (isLoading) {
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }
}

/* ------------------------------------------------------------
   API CALL - Gemini generateContent endpoint
   ------------------------------------------------------------ */
async function getBotReply(contents) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${CONFIG.model}:generateContent?key=${CONFIG.apiKey}`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: contents,
      systemInstruction: {
        parts: [{ text: CONFIG.systemPrompt }]
      }
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`API error ${response.status}: ${errText}`);
  }

  const data = await response.json();

  const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!reply) {
    throw new Error("Unexpected response format from Gemini API.");
  }

  return reply.trim();
}